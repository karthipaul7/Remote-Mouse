﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using InTheHand.Net.Bluetooth;
using InTheHand.Net.Sockets;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Thread _listenerThread;
        private BluetoothListener _listener;
        private volatile bool _isListening;

        // Constants for key codes
        const uint KEYEVENTF_KEYDOWN = 0x0000;
        const uint KEYEVENTF_KEYUP = 0x0002;
        const ushort VK_LWIN = 0x5B;
        const ushort VK_D = 0x44;
        const int KEYEVENTF_EXTENDEDKEY = 0x0001;
        const int VK_MENU = 0x12;
        const int VK_TAB = 0x09;

        // Importing SendInput from User32.dll
        [DllImport("user32.dll", SetLastError = true)]
        public static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);



        [StructLayout(LayoutKind.Sequential)]
        public struct INPUT
        {
            public uint type;
            public InputUnion u;
        }

        [StructLayout(LayoutKind.Explicit)]
        public struct InputUnion
        {
            [FieldOffset(0)] public MOUSEINPUT mi;
            [FieldOffset(0)] public KEYBDINPUT ki;
            [FieldOffset(0)] public HARDWAREINPUT hi;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct MOUSEINPUT
        {
            public int dx;
            public int dy;
            public uint mouseData;
            public uint dwFlags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct KEYBDINPUT
        {
            public ushort wVk;
            public ushort wScan;
            public uint dwFlags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct HARDWAREINPUT
        {
            public uint uMsg;
            public ushort wParamL;
            public ushort wParamH;
        }
        public MainWindow()
        {
            InitializeComponent();
            _listener = new BluetoothListener(BluetoothService.SerialPort);
        }

        // Method to trigger Win + D
        static void SendWinD()
        {
            INPUT[] inputs = new INPUT[4];

            // Press down the Win key
            inputs[0] = new INPUT
            {
                type = 1, // Keyboard input
                u = new InputUnion
                {
                    ki = new KEYBDINPUT
                    {
                        wVk = VK_LWIN,
                        dwFlags = KEYEVENTF_KEYDOWN
                    }
                }
            };

            // Press down the D key
            inputs[1] = new INPUT
            {
                type = 1,
                u = new InputUnion
                {
                    ki = new KEYBDINPUT
                    {
                        wVk = VK_D,
                        dwFlags = KEYEVENTF_KEYDOWN
                    }
                }
            };

            // Release the D key
            inputs[2] = new INPUT
            {
                type = 1,
                u = new InputUnion
                {
                    ki = new KEYBDINPUT
                    {
                        wVk = VK_D,
                        dwFlags = KEYEVENTF_KEYUP
                    }
                }
            };

            // Release the Win key
            inputs[3] = new INPUT
            {
                type = 1,
                u = new InputUnion
                {
                    ki = new KEYBDINPUT
                    {
                        wVk = VK_LWIN,
                        dwFlags = KEYEVENTF_KEYUP
                    }
                }
            };

            // Send the input array
            SendInput((uint)inputs.Length, inputs, Marshal.SizeOf(typeof(INPUT)));
        }


        private void switchbetweenTab()
        {
            // Press Alt
            keybd_event(VK_MENU, 0, KEYEVENTF_EXTENDEDKEY, UIntPtr.Zero);
            // Press Tab
            keybd_event(VK_TAB, 0, KEYEVENTF_EXTENDEDKEY, UIntPtr.Zero);

            // Release Tab
            keybd_event(VK_TAB, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
            // Release Alt
            keybd_event(VK_MENU, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
        }


        private void StartBluetoothListener()
        {
            try
            {
                _listener.Start(); // Start listening
                while (true) // Keep listening for connections
                {
                    BluetoothClient client = _listener.AcceptBluetoothClient();
                    ThreadPool.QueueUserWorkItem(state => HandleClient(client));
                }
            }
            catch (Exception ex)
            {
                // MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void HandleClient(BluetoothClient client)
        {
            try
            {
                using (System.IO.Stream peerStream = client.GetStream())
                {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = peerStream.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        string receivedMessage = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                        AppendText(receivedMessage); // Append to UI or log
                    }
                }
            }
            catch (Exception ex)
            {
                // MessageBox.Show($"Client connection error: {ex.Message}");
            }
            finally
            {
                client.Close(); // Close client after processing
            }
        }


        private void AppendText(string text)
        {

            // Use Dispatcher to ensure thread-safe UI updates
            Dispatcher.Invoke(() =>
            {
                if (text == "Win+D")
                {
                    // Trigger Win + D to minimize all windows
                    SendWinD();

                }
                else if (text == "Ctrl+N")
                {
                    SendKeys.SendWait("^n");
                }
                else if (text == "Ctrl+O" || text == "ADOBE_OPEN_FILE")
                {
                    SendKeys.SendWait("^o");
                }
                else if (text == "Ctrl+S")
                {
                    SendKeys.SendWait("^s");
                }
                else if (text == "Ctrl+U")
                {
                    SendKeys.SendWait("^u");
                }
                else if (text == "Ctrl+A")
                {
                    SendKeys.SendWait("^a");
                }
                else if (text == "Ctrl+W")
                {
                    SendKeys.SendWait("^w");
                }
                else if (text == "Alt+F4")
                {
                    SendKeys.SendWait("%{F4}");
                }
                else if (text == "Alt+PageDown")
                {
                    SendKeys.SendWait("%{PGDN}");
                }
                else if (text == "Alt+PageUp")
                {
                    SendKeys.SendWait("%{PGUP}");
                }
                else if (text == "Alt+Tab")
                {
                    switchbetweenTab();
                }
                else if (text == "ADOBE_SAVE")
                {
                    SendKeys.SendWait("^s");
                }
                else if (text == "ADOBE_SAVE_AS")
                {
                    SendKeys.SendWait("^+S");
                }
                else if (text == "ADOBE_FIND_TOOLS")
                {
                    SendKeys.SendWait("^f");
                }
                else if (text == "ADOBE_DIALOGUE")
                {
                    SendKeys.SendWait("^k");
                }
                else if (text == "ADOBE_DOCUMENT")
                {
                    SendKeys.SendWait("^d");
                }
                else if (text == "ADOBE_SWITCH")
                {
                    SendKeys.SendWait("^{Tab}");
                }
                else if (text == "ADOBE_STICKY_NOTE")
                {
                    SendKeys.SendWait("^e");
                }



                else
                {
                    var specialCharacters = new HashSet<String> { "+", "^", "%", "~", "(", ")", "{", "}", "[", "]" };

                    if (specialCharacters.Contains(text))
                    {
                        SendKeys.SendWait("{" + text + "}");

                    }
                    else if (text == "Win+D")
                    {

                        SendWinD();
                    }
                    else
                    {
                        SendKeys.SendWait(text);
                    }
                }
                //MessageBox.Show(text);
                // KeyboardSimulator.SendKey(0x41); // Simulating key press
            });
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // Start the Bluetooth listener in a background thread
            _listenerThread = new Thread(StartBluetoothListener)
            {
                IsBackground = true
            };
            _listenerThread.Start();
            System.Windows.Forms.MessageBox.Show("Listening....");
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            // Stop the Bluetooth listener when the window is closed
            _isListening = false;
            _listener.Stop();

            // Ensure the listener thread is properly terminated
            if (_listenerThread != null && _listenerThread.IsAlive)
            {
                _listenerThread.Join();
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Stop the Bluetooth listener when the window is closed
            _isListening = false;
            _listener.Stop();

            // Ensure the listener thread is properly terminated
            if (_listenerThread != null && _listenerThread.IsAlive)
            {
                _listenerThread.Join();
            }
        }
    }
}